/*****************************************************************************/
/*                                                                           */
/*  main.cpp                                             TTTTTTTT SSSSSSS II */
/*                                                          TT    SS      II */
/*  By: st93642@students.tsi.lv                             TT    SSSSSSS II */
/*                                                          TT         SS II */
/*  Created: May 16 2026 12:46 st93642                      TT    SSSSSSS II */
/*  Updated: May 20 2026 15:39 st93642                                       */
/*                                                                           */
/*   Transport and Telecommunication Institute - Riga, Latvia                */
/*                       https://tsi.lv                                      */
/*****************************************************************************/

#include <cstdint>
#include <cstring>
#include <cstddef>
#include <fstream>
#include <iostream>
#include <limits>

const std::size_t	MAX_SHOPS = 100;
const char			*DATABASE_FILE = "shops.dat";

struct Shop
{
	char title[64];
	char address[128];
	char phone[32];
};

std::size_t readShops(Shop *shops)
{
	std::ifstream file(DATABASE_FILE, std::ios::binary);
	std::int32_t	rawCount = 0;
	std::size_t		count;

	if (!file) return (0);
	file.read(reinterpret_cast<char *>(&rawCount), sizeof(rawCount));
	if (!file || rawCount < 0 
		|| static_cast<std::size_t>(rawCount) > MAX_SHOPS) 
		return (0);
	count = static_cast<std::size_t>(rawCount);
	if (count > 0)
	{
		file.read(reinterpret_cast<char *>(shops), sizeof(Shop) * count);
		if (!file) return (0);
	}
	return (count);
}

bool writeShops(const Shop *shops, std::size_t count)
{
	std::ofstream file(DATABASE_FILE, std::ios::binary);
	std::int32_t rawCount = static_cast<std::int32_t>(count);

	if (!file)
	{
		std::cout << "Cannot open file for writing\n";
		return (false);
	}
	file.write(reinterpret_cast<const char *>(&rawCount), sizeof(rawCount));
	file.write(reinterpret_cast<const char *>(shops), sizeof(Shop) * count);
	if (!file)
	{
		std::cout << "Cannot write data to file\n";
		return (false);
	}
	return (true);
}

void addData(Shop *shops, std::size_t *count)
{
	std::size_t i = *count;

	if (i >= MAX_SHOPS)
	{
		std::cout << "Database is full\n";
		return;
	}

	std::memset(&shops[i], 0, sizeof(Shop));

	std::cout << "Enter shop title: ";
	std::cin.getline(shops[i].title, 64);
	if (std::cin.fail())
	{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cout << "Input error: title too long\n";
		return;
	}
	std::cout << "Enter address: ";
	std::cin.getline(shops[i].address, 128);
	if (std::cin.fail())
	{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cout << "Input error: address too long\n";
		return;
	}
	std::cout << "Enter tel. number: ";
	std::cin.getline(shops[i].phone, 32);
	if (std::cin.fail())
	{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cout << "Input error: phone number too long\n";
		return;
	}
	*count = i + 1;
	if (!writeShops(shops, *count))
	{
		*count = i;
		return;
	}
	std::cout << "Data saved\n";
}

void viewData(const Shop *shops, std::size_t count)
{
	if (!count)
	{
		std::cout << "File is empty or does not exist\n";
		return;
	}
	std::cout << "\nShops in file: " << count << '\n';
	for (std::size_t i = 0; i < count; i++)
	{
		std::cout << "Shop " << i + 1 << ":\n"
				  << "  Title: " << shops[i].title << '\n'
				  << "  Address: " << shops[i].address << '\n'
				  << "  Tel. number: " << shops[i].phone << '\n';
	}
}

void definePhoneByAddress(const Shop *shops, std::size_t count)
{
	char address[128];

	if (!count)
	{
		std::cout << "File is empty or does not exist\n";
		return;
	}
	std::cout << "Enter address: ";
	std::cin.getline(address, 128);
	if (std::cin.fail())
	{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cout << "Input error: address too long\n";
		return;
	}
	for (std::size_t i = 0; i < count; i++)
	{
		if (std::strcmp(shops[i].address, address) == 0)
		{
			std::cout << "Tel. number: " << shops[i].phone << '\n';
			return;
		}
	}
	std::cout << "Shop with this address was not found\n";
}

int main(void)
{
	Shop shops[MAX_SHOPS];
	std::size_t	count = readShops(shops);
	int			menuItem;

	std::cout << "Task 2\n";
	for (;;)
	{
		std::cout << "\nMenu:\n"
				  << "1. Add data\n"
				  << "2. View data\n"
				  << "3. Define tel. number by address\n"
				  << "4. Exit\n"
				  << "Enter menu item: ";
		if (!(std::cin >> menuItem))
		{
			std::cin.clear();
			std::cout << "Invalid menu item\n";
		}
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		if (menuItem == 1)
			addData(shops, &count);
		else if (menuItem == 2)
			viewData(shops, count);
		else if (menuItem == 3)
			definePhoneByAddress(shops, count);
		else if (menuItem == 4)
			break;
		else
			std::cout << "Invalid menu item\n";
	}
	return (0);
}
